function DisVec = Dis2point(x)
% x is [x,y,z] cordinates of each point
    [mc nc]=size(x);
    Dx=zeros(mc,mc);
for j=1:mc
   Dx(:,j) = sqrt(sum((x-x(j,:)).^2,2));
end
Dx_T=Dx;

for j=1:mc
    for i=1:mc
        if j>i
            Dx_T(i,j)=0;
        else
            Dx_T(i,j)=Dx_T(i,j);
        end
    end
end

DisVec=nonzeros(Dx_T);